#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
    char first[100] = "Chuan-Ju";
    printf("%s %f",first, sin(10));
    return (0);
}
