#!/usr/bin/env bash

for i in {1..5}
do
    mkdir dir_$i
done


