#!/usr/bin/env bash

for i in {1..5}
do
    echo "Welcome $i times"
done


echo "Bash version ${BASH_VERSION}..."
for i in {0..10..2}
do
    echo "Welcome $i times"
done


