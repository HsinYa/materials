#!/bin/bash

mkdir .Trash
mv .Trash Trash
cp -r Trash Trash2
cd Trash
mkdir .Trash
