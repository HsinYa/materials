if grep "UNIX" myfile >/dev/null
then
    echo "It's there"
fi
