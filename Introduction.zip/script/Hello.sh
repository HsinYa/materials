#!/bin/bash
# This is a commented line, will not be executed 
# # This is my first script "Hello World"
echo "Hello World"
