#include <stdio.h>
int haha(char name[15])
{
	printf ("\n\nHi, Dear %s, nice to meet you.", name);
}
